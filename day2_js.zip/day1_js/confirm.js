function myalert(mag){
    if(confirm("Are you sure want to display the massage?????")){
        alert(msg);
    }
    else{
        alert("massage not displayed as user canceled");
    }
    
    
    
}